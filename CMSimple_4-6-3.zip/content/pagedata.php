<?php 
/* utf8-marker = äöüß */ 
################## Data fields ############
$page_data_fields[] = 'url';
$page_data_fields[] = 'last_edit';
$page_data_fields[] = 'description';
$page_data_fields[] = 'keywords';
$page_data_fields[] = 'title';
$page_data_fields[] = 'robots';
$page_data_fields[] = 'heading';
$page_data_fields[] = 'show_heading';
$page_data_fields[] = 'template';
$page_data_fields[] = 'published';
$page_data_fields[] = 'show_last_edit';
$page_data_fields[] = 'linked_to_menu';
$page_data_fields[] = 'header_location';
$page_data_fields[] = 'use_header_location';

################## Recently deleted ############
$temp_data['url'] = 'RealBlog';
$temp_data['last_edit'] = '1347389705';
$temp_data['description'] = '';
$temp_data['keywords'] = '';
$temp_data['title'] = '';
$temp_data['robots'] = '';
$temp_data['heading'] = '';
$temp_data['show_heading'] = '';
$temp_data['template'] = '';
$temp_data['published'] = '';
$temp_data['show_last_edit'] = '';
$temp_data['linked_to_menu'] = '';
$temp_data['header_location'] = '';
$temp_data['use_header_location'] = '';

################## Page Data ############
$page_data[0]['url'] = 'Welcome_to_CMSimple';
$page_data[0]['last_edit'] = '1417093623';
$page_data[0]['description'] = '';
$page_data[0]['keywords'] = '';
$page_data[0]['title'] = '';
$page_data[0]['robots'] = '';
$page_data[0]['heading'] = '';
$page_data[0]['show_heading'] = '0';
$page_data[0]['template'] = '0';
$page_data[0]['published'] = '1';
$page_data[0]['show_last_edit'] = '0';
$page_data[0]['linked_to_menu'] = '1';
$page_data[0]['header_location'] = '';
$page_data[0]['use_header_location'] = '0';

//----------
$page_data[1]['url'] = 'Menu_Levels_%26amp%3B_Headings';
$page_data[1]['last_edit'] = '1347539918';
$page_data[1]['description'] = '';
$page_data[1]['keywords'] = '';
$page_data[1]['title'] = '';
$page_data[1]['robots'] = '';
$page_data[1]['heading'] = '';
$page_data[1]['show_heading'] = '0';
$page_data[1]['template'] = '0';
$page_data[1]['published'] = '1';
$page_data[1]['show_last_edit'] = '0';
$page_data[1]['linked_to_menu'] = '1';
$page_data[1]['header_location'] = '';
$page_data[1]['use_header_location'] = '0';

//----------
$page_data[2]['url'] = 'Menu_Level_2_-_Page_1';
$page_data[2]['last_edit'] = '1354476823';
$page_data[2]['description'] = '';
$page_data[2]['keywords'] = '';
$page_data[2]['title'] = '';
$page_data[2]['robots'] = '';
$page_data[2]['heading'] = '';
$page_data[2]['show_heading'] = '';
$page_data[2]['template'] = '';
$page_data[2]['published'] = '';
$page_data[2]['show_last_edit'] = '';
$page_data[2]['linked_to_menu'] = '1';
$page_data[2]['header_location'] = '';
$page_data[2]['use_header_location'] = '';

//----------
$page_data[3]['url'] = 'Menu_Level_3_-_Page_1';
$page_data[3]['last_edit'] = '1354476803';
$page_data[3]['description'] = '';
$page_data[3]['keywords'] = '';
$page_data[3]['title'] = '';
$page_data[3]['robots'] = '';
$page_data[3]['heading'] = '';
$page_data[3]['show_heading'] = '';
$page_data[3]['template'] = '';
$page_data[3]['published'] = '';
$page_data[3]['show_last_edit'] = '';
$page_data[3]['linked_to_menu'] = '1';
$page_data[3]['header_location'] = '';
$page_data[3]['use_header_location'] = '';

//----------
$page_data[4]['url'] = 'Menu_Level_3_-_Page_2';
$page_data[4]['last_edit'] = '1354476860';
$page_data[4]['description'] = '';
$page_data[4]['keywords'] = '';
$page_data[4]['title'] = '';
$page_data[4]['robots'] = '';
$page_data[4]['heading'] = '';
$page_data[4]['show_heading'] = '';
$page_data[4]['template'] = '';
$page_data[4]['published'] = '';
$page_data[4]['show_last_edit'] = '';
$page_data[4]['linked_to_menu'] = '1';
$page_data[4]['header_location'] = '';
$page_data[4]['use_header_location'] = '';

//----------
$page_data[5]['url'] = 'Menu_Level_3_-_Page_3';
$page_data[5]['last_edit'] = '1354476909';
$page_data[5]['description'] = '';
$page_data[5]['keywords'] = '';
$page_data[5]['title'] = '';
$page_data[5]['robots'] = '';
$page_data[5]['heading'] = '';
$page_data[5]['show_heading'] = '';
$page_data[5]['template'] = '';
$page_data[5]['published'] = '';
$page_data[5]['show_last_edit'] = '';
$page_data[5]['linked_to_menu'] = '1';
$page_data[5]['header_location'] = '';
$page_data[5]['use_header_location'] = '';

//----------
$page_data[6]['url'] = 'Menu_Level_2_-_Page_2';
$page_data[6]['last_edit'] = '1354476919';
$page_data[6]['description'] = '';
$page_data[6]['keywords'] = '';
$page_data[6]['title'] = '';
$page_data[6]['robots'] = '';
$page_data[6]['heading'] = '';
$page_data[6]['show_heading'] = '';
$page_data[6]['template'] = '';
$page_data[6]['published'] = '';
$page_data[6]['show_last_edit'] = '';
$page_data[6]['linked_to_menu'] = '1';
$page_data[6]['header_location'] = '';
$page_data[6]['use_header_location'] = '';

//----------
$page_data[7]['url'] = 'Menu_Level_3_-_Page_1';
$page_data[7]['last_edit'] = '1354476929';
$page_data[7]['description'] = '';
$page_data[7]['keywords'] = '';
$page_data[7]['title'] = '';
$page_data[7]['robots'] = '';
$page_data[7]['heading'] = '';
$page_data[7]['show_heading'] = '';
$page_data[7]['template'] = '';
$page_data[7]['published'] = '';
$page_data[7]['show_last_edit'] = '';
$page_data[7]['linked_to_menu'] = '1';
$page_data[7]['header_location'] = '';
$page_data[7]['use_header_location'] = '';

//----------
$page_data[8]['url'] = 'Menu_Level_3_-_Page_2';
$page_data[8]['last_edit'] = '1354476937';
$page_data[8]['description'] = '';
$page_data[8]['keywords'] = '';
$page_data[8]['title'] = '';
$page_data[8]['robots'] = '';
$page_data[8]['heading'] = '';
$page_data[8]['show_heading'] = '';
$page_data[8]['template'] = '';
$page_data[8]['published'] = '';
$page_data[8]['show_last_edit'] = '';
$page_data[8]['linked_to_menu'] = '1';
$page_data[8]['header_location'] = '';
$page_data[8]['use_header_location'] = '';

//----------
$page_data[9]['url'] = 'Menu_Level_3_-_Page_3';
$page_data[9]['last_edit'] = '1354476945';
$page_data[9]['description'] = '';
$page_data[9]['keywords'] = '';
$page_data[9]['title'] = '';
$page_data[9]['robots'] = '';
$page_data[9]['heading'] = '';
$page_data[9]['show_heading'] = '';
$page_data[9]['template'] = '';
$page_data[9]['published'] = '';
$page_data[9]['show_last_edit'] = '';
$page_data[9]['linked_to_menu'] = '1';
$page_data[9]['header_location'] = '';
$page_data[9]['use_header_location'] = '';

//----------
$page_data[10]['url'] = 'Menu_Level_2_-_Page_3';
$page_data[10]['last_edit'] = '1354477066';
$page_data[10]['description'] = '';
$page_data[10]['keywords'] = '';
$page_data[10]['title'] = '';
$page_data[10]['robots'] = '';
$page_data[10]['heading'] = '';
$page_data[10]['show_heading'] = '';
$page_data[10]['template'] = '';
$page_data[10]['published'] = '';
$page_data[10]['show_last_edit'] = '';
$page_data[10]['linked_to_menu'] = '1';
$page_data[10]['header_location'] = '';
$page_data[10]['use_header_location'] = '';

//----------
$page_data[11]['url'] = 'Menu_Level_3_-_Page_1';
$page_data[11]['last_edit'] = '1354477088';
$page_data[11]['description'] = '';
$page_data[11]['keywords'] = '';
$page_data[11]['title'] = '';
$page_data[11]['robots'] = '';
$page_data[11]['heading'] = '';
$page_data[11]['show_heading'] = '';
$page_data[11]['template'] = '';
$page_data[11]['published'] = '';
$page_data[11]['show_last_edit'] = '';
$page_data[11]['linked_to_menu'] = '1';
$page_data[11]['header_location'] = '';
$page_data[11]['use_header_location'] = '';

//----------
$page_data[12]['url'] = 'Menu_Level_3_-_Page_2';
$page_data[12]['last_edit'] = '1354476984';
$page_data[12]['description'] = '';
$page_data[12]['keywords'] = '';
$page_data[12]['title'] = '';
$page_data[12]['robots'] = '';
$page_data[12]['heading'] = '';
$page_data[12]['show_heading'] = '';
$page_data[12]['template'] = '';
$page_data[12]['published'] = '';
$page_data[12]['show_last_edit'] = '';
$page_data[12]['linked_to_menu'] = '1';
$page_data[12]['header_location'] = '';
$page_data[12]['use_header_location'] = '';

//----------
$page_data[13]['url'] = 'Menu_Level_3_-_Page_3';
$page_data[13]['last_edit'] = '1354476992';
$page_data[13]['description'] = '';
$page_data[13]['keywords'] = '';
$page_data[13]['title'] = '';
$page_data[13]['robots'] = '';
$page_data[13]['heading'] = '';
$page_data[13]['show_heading'] = '';
$page_data[13]['template'] = '';
$page_data[13]['published'] = '';
$page_data[13]['show_last_edit'] = '';
$page_data[13]['linked_to_menu'] = '1';
$page_data[13]['header_location'] = '';
$page_data[13]['use_header_location'] = '';

//----------
$page_data[14]['url'] = 'Templates_%26amp%3B_Plugins';
$page_data[14]['last_edit'] = '1352296368';
$page_data[14]['description'] = '';
$page_data[14]['keywords'] = '';
$page_data[14]['title'] = '';
$page_data[14]['robots'] = '';
$page_data[14]['heading'] = '';
$page_data[14]['show_heading'] = '';
$page_data[14]['template'] = '';
$page_data[14]['published'] = '';
$page_data[14]['show_last_edit'] = '';
$page_data[14]['linked_to_menu'] = '1';
$page_data[14]['header_location'] = '';
$page_data[14]['use_header_location'] = '';

//----------
$page_data[15]['url'] = 'Languages';
$page_data[15]['last_edit'] = '1417093716';
$page_data[15]['description'] = '';
$page_data[15]['keywords'] = '';
$page_data[15]['title'] = '';
$page_data[15]['robots'] = '';
$page_data[15]['heading'] = '';
$page_data[15]['show_heading'] = '';
$page_data[15]['template'] = '';
$page_data[15]['published'] = '';
$page_data[15]['show_last_edit'] = '';
$page_data[15]['linked_to_menu'] = '1';
$page_data[15]['header_location'] = '';
$page_data[15]['use_header_location'] = '';

//----------
$page_data[16]['url'] = 'News01';
$page_data[16]['last_edit'] = '1380103919';
$page_data[16]['description'] = '';
$page_data[16]['keywords'] = '';
$page_data[16]['title'] = '';
$page_data[16]['robots'] = '';
$page_data[16]['heading'] = '';
$page_data[16]['show_heading'] = '0';
$page_data[16]['template'] = '0';
$page_data[16]['published'] = '1';
$page_data[16]['show_last_edit'] = '0';
$page_data[16]['linked_to_menu'] = '0';
$page_data[16]['header_location'] = '';
$page_data[16]['use_header_location'] = '0';

//----------
$page_data[17]['url'] = 'News02';
$page_data[17]['last_edit'] = '1380103969';
$page_data[17]['description'] = '';
$page_data[17]['keywords'] = '';
$page_data[17]['title'] = '';
$page_data[17]['robots'] = '';
$page_data[17]['heading'] = '';
$page_data[17]['show_heading'] = '0';
$page_data[17]['template'] = '0';
$page_data[17]['published'] = '1';
$page_data[17]['show_last_edit'] = '0';
$page_data[17]['linked_to_menu'] = '0';
$page_data[17]['header_location'] = '';
$page_data[17]['use_header_location'] = '0';

//----------
$page_data[18]['url'] = 'News03';
$page_data[18]['last_edit'] = '1380104007';
$page_data[18]['description'] = '';
$page_data[18]['keywords'] = '';
$page_data[18]['title'] = '';
$page_data[18]['robots'] = '';
$page_data[18]['heading'] = '';
$page_data[18]['show_heading'] = '0';
$page_data[18]['template'] = '0';
$page_data[18]['published'] = '1';
$page_data[18]['show_last_edit'] = '0';
$page_data[18]['linked_to_menu'] = '0';
$page_data[18]['header_location'] = '';
$page_data[18]['use_header_location'] = '0';

//----------
?>