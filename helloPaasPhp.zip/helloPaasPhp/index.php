<!DOCTYPE html>
<html>
<head>
	<title>PHP sample of Fujitsu PaaS</title>
</head>
<body>
	<?php echo  '<p>Hello, welcome to Fujitsu PaaS!</p>'; ?>
</body>
</html>
