
# hello.rb
require 'sinatra'
get '/' do
  "hello world"
end



