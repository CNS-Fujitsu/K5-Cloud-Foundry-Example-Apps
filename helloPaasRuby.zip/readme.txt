
- in usual way declare application dependencies inside 'Gemfile'
- run 'bundle' to process them 
- create 'Procfile' to run application, in this case, "web: ruby hello.rb" 
- zip and deploy to CF 
!

